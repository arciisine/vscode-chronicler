extern const char* locale_charset(void);
