#include "localcharset.h"

const char *locale_charset(void) {
  return "";
}
